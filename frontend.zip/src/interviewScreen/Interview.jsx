import React from "react";
import NewInterview from "./NewInterview";
import Timer from "./Timer";
import EditInterView from "./EditInterview";
import { useState } from "react";

function Interview() {
  return (
    <div>
      <EditInterView></EditInterView>
    </div>
  );
}

export default Interview;
